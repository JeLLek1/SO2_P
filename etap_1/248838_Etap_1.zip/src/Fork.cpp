#include "Fork.hpp"

Fork::Fork(size_t no){
    _no = no;
    isTaken = false;
}
