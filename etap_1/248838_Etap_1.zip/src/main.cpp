#include "Scheduler.hpp"
#include <ncurses.h>

int main() {
    Scheduler();
    endwin();
 
    return 0;
}
