#pragma once

const int philosophersCount = 5;
const int sleepMs = 3000;
const int eatMs = 2000;
const int refreshTime = 500;
